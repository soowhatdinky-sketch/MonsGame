# SPHEROCAL — MASSIVE SCI-FI SHIP

Godot 4.x capital-ship expansion built around the supplied Spherocal OBJ.

### Scale
The supplied hull is enlarged by **3.6×**, producing an approximate envelope of:
- Length: ~1591 m
- Width: ~2371 m
- Height: ~426 m
- 12 procedural decks
- Large forward/aft hangars
- Engineering, reactor and command zones

### Sci-Fi Starter Kit
Copy your `Sci-Fi_Starter_Kit` folder into the project root:
`res://Sci-Fi_Starter_Kit/`

`PrefabDeckBuilder.gd` recursively finds `.tscn` scenes and instances up to 300 of them across the interior framework. Adjust `prefab_limit` and `_grid_position()` for your kit.

### Included
- Godot 4 project and scenes
- Massive ship controller
- Procedural deck/interior generator
- Automatic starter-kit prefab placer
- Hull panel/emission shader
- Energy-field shader
- Reactor glow shader

Open the folder in Godot and press **Run Project**.
